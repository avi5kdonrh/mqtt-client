java -jar java-sftp-1.0.0-jar-with-dependencies.jar hostname username keylocation passphrase remote_file_name local_directory_name known_hosts
